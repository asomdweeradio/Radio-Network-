# ASOMDWEE RADIO NETWORK — One-Link Listener Website

This is a simple shareable webpage containing all three stations.

Stations:
- ASOMDWEE RADIO — http://s37.myradiostream.com:8380/listen.mp3
- ASETENAPA RADIO — http://s19.myradiostream.com:17912/listen.mp3
- NSROMA RADIO — http://s23.myradiostream.com:17566/listen.mp3

Upload the contents of this folder to any HTTPS static website host. The public link can then be shared with listeners.

IMPORTANT:
The supplied streams are HTTP. Modern browsers can block HTTP audio when the page itself is HTTPS. MyRadioStream states that its Webcaster Plus plan provides TLS/HTTPS stream URLs for secure websites/apps. Before public launch, replace each URL in index.html with the HTTPS stream URL supplied by MyRadioStream if your current plan supports it.

The page itself is ready: one link, three station choices, one LISTEN LIVE button.
